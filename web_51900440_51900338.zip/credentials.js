module.exports = {
    cookieSecret: "your cookie secret goes here",
};